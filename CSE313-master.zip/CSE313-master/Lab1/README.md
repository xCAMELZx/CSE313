
#Lab 1 ALU OPERATIONS
1.1 Problem Statement
The numbers X and Y are found at locations x3100 and x3101, respectively. Write an LC-3 assembly
language program that does the following.
####
• Compute the sum X +Y and place it at location x3102.
######
• Compute X AND Y and place it at location x3103.
######
• Compute X OR Y and place it at location x3104.
######
• Compute NOT(X) and place it at location x3105.
######
• Compute NOT(Y) and place it at location x3106.
######
• Compute X +3 and place it at location x3107.
######
• Compute Y −3 and place it at location x3108.
######
• If the X is even, place 0 at location x3109. If the number is odd, place 1 at the same location.

The operations AND, OR, and NOT are bitwise. The operation signified by + is the usual
arithmetic addition.
